class foreign {
	public:
		foreign ();
};
