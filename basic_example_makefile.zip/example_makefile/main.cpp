#include <iostream>
#include "class.h"    // user defined class kept in quotes instead of <>

using namespace std;

int main() {
	std::cout<<"hello main!"<<std::endl;
	foreign obj;
return 0;
}
