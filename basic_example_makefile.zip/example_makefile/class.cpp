#include <iostream>
#include "class.h"

using namespace std;

foreign::foreign() {
	std::cout<<"entered a foreign class! "<<std::endl;
}
